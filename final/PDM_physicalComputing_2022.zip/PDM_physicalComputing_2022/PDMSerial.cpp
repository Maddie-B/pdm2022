

#include "Arduino.h"
#include "PDMSerial.h"

PDMSerial::PDMSerial()
{
  _startingTransmit = true;
  _name = "default";
  _value = 0;
}

String PDMSerial::getName() {
  return _name;
}

int PDMSerial::getValue() {
  return _value;
}

boolean PDMSerial::checkSerial() {
       
  if (Serial.available() > 0) {
    
    String data = String(Serial.readStringUntil(','));
    if(data!= "\n") {
      
      
      int sep = data.indexOf(":");
      if(sep != -1) {
      
        
        _name = data.substring(0,sep);
        
        _value = data.substring(sep+1).toInt();
        
        if(_name && _value >= 0) {
           
          return true;
        }
      }
    }
  } 
    return false; // no new data or the data wasn't good.
}

// **********************************************
// ********* LSU DDEM Data Transmission ********* 
// **********************************************
//
// Transmit as many sensors as you like then send end before looping.
// transmitSensor(string name, int/float value);
  // transmitSensor("a0", sensorValue);
  // transmitSensor("float0", sensorFloatValue);
  // transmitSensor("b7", buttonState);
  // transmitSensor("end");

void PDMSerial::transmitSensor(String name, int value) {
  if (name == "end") {
      Serial.write(";\n");
      _startingTransmit = true;
  } else {
          // Only put a comma on after the first transmitted data.
      if(_startingTransmit) {
        _startingTransmit = false;
      } else {
        Serial.write(",");
      }
      
        // Prep the data 
    String xmitData = name + ":" + String(value);
      // Transmission to the computer
    Serial.write(xmitData.c_str());
  }
}

void PDMSerial::transmitSensor(String name, float value) {
  if (name == "end") {
      Serial.write(";\n");
      _startingTransmit = true;
  } else {
          // Only put a comma on after the first transmitted data.
      if(_startingTransmit) {
        _startingTransmit = false;
      } else {
        Serial.write(",");
      }
      
        // Prep the data 
    String xmitData = name + ":" + String(value);
      // Transmission to the computer
    Serial.write(xmitData.c_str());
  }
}

void PDMSerial::transmitSensor(String name) {
  if (name == "end") {
      Serial.write(";\n");
      _startingTransmit = true;
  } else {
        // Prep the data 
    String xmitData = name + "\n";
      // Transmission to the computer
    Serial.write(xmitData.c_str());
  }
}
