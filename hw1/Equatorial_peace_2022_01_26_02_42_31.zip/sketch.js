function setup() {
  createCanvas(400, 400);
  background(900);
  
  fill(0, 0, 220, 150);
  noStroke();
  ellipse(140, 260, 230, 230);
  
  fill(0, 220, 0, 150);
  ellipse(260, 260, 230, 230);
  
  fill(0, 0, 220, 150);
  ellipse(200, 140, 230, 230);
}

function draw() {
  background(220);
}