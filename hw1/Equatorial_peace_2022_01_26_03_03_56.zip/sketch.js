function setup() {
  createCanvas(400, 400);
  background(0, 0, 120, 300);
  
  fill(0, 120, 0, 300);
  stroke(500);
  ellipse(200, 200, 180, 180);
  
  fill(300, 0, 0, 400);
  stroke(500);
  

  
}

function draw() {
  background(220);
  
}