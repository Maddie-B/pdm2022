function setup() {
  createCanvas(720, 400);
  background(34, 272, 90, 100);
  
  fill(500);
  stroke(10);
  
  ellipse(200, 200, 340, 340);
  rect(420, 30, 340, 340);
}

function draw() {
  background(220);
}