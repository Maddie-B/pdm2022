function setup() {
  createCanvas(720, 400);
  background(10);
  
  fill(225, 225, 0, 400);
  ellipse(200, 200, 340, 340);
  
  fill(500, 60, 40, 210);
  rect(420, 160, 340, 200);
  arc(590, 170, 340, 280, PI, TWO_PI);
  
  fill(10);
  triangle(20, 80, 200, 200, 20, 360);
  
  fill(300);
  ellipse(500, 190, 100, 100);
  ellipse(670, 190, 100, 100);
  
  fill(80, 10, 240, 300);
  ellipse(500, 190, 60, 60);
  ellipse(670, 190, 60, 60);
}

function draw() {
  background(220);
}